//this class contains the Law of CoSines


import java.lang.Math ;

public class Abhishek
{

		//double a, b, c, A, B, C ;	//Lowercase is angles, uppercase is sides, C is hypotenuse
		//archaic code, as it does nothing
	//Abhishek originally had it input things in different "shapped" sets, but I ended up unifiying it with Arrays, -Jaime
		
	public static double[] AaCc(double[] set){//Between A,a,C,c
		double A = set[0], a = set[1], B = set[2], b = set[3], C = set[4], c = set[5];
		if ( b == 0 && B == 0)
		{
			if( a == 0 )
			{
				a = A*(Math.sin(c)/C) ;
			}
			if( A == 0 )
			{
				A = C*(Math.sin(a)/Math.sin(c)) ;
			}
			if( c == 0 )
			{
				c = C*(Math.sin(a)/A) ;
			}
			if( C == 0)
			{
				C = A*(Math.sin(c)/Math.sin(a)) ;
			}
		}
		double newset[] = {A,a,B,b,C,c};
		return newset;
		}

	public static double[] AaBb(double[] set){//Between A,a,B,b
		double A = set[0], a = set[1], B = set[2], b = set[3], C = set[4], c = set[5];

			if( a == 0 )
			{
				a = A*(Math.sin(b)/B) ;
			}
			if( A == 0 )
			{
				A = B*(Math.sin(a)/Math.sin(b)) ;
			}
			if( b == 0 )
			{
				b = B*(Math.sin(a)/A) ;
			}
			if( B == 0 )
			{
				B = A*(Math.sin(b)/Math.sin(a)) ;
			}

		double newset[] = {A,a,B,b,C,c};
		return newset;
	}
		
	
	public static double[] BbCc(double[] set){//Between B,b,C,c REQUIRES BCC
		double A = set[0], a = set[1], B = set[2], b = set[3], C = set[4], c = set[5];

			if( b == 0 )
			{
				b = B*(Math.sin(c)/C) ;
			}
			if( B == 0 )
			{
				B = C*(Math.sin(b)/Math.sin(c)) ;
			}
			if( c == 0 )
			{
				c = C*(Math.sin(b)/B) ;
			}
			if( C == 0 )
			{
				C = B*(Math.sin(c)/Math.sin(b)) ;
			}
	
		double newset[] = {A,a,B,b,C,c};
		return newset;
	}

}
