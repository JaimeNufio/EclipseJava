
public class Isaiah {
	//ISAIAH WROTE TRIANGLE
    String [] TriANGLE = {"Right Triangle", "Obtuse Triangle", "Acute Triangle", "Not a Triangle"};                
    String [] TRIangle = {"Scalene ", "Equilateral ","Isoseles ", ""};
    static double a, b, c, A, B, C;
        
    public static int i(double[] set)//Value for the TriANGLE Array
    {
    //the convention here is that A is a side, and a is an angle
    //ALL ANGLES REQUIRED
    
        if ((a == 90 || b == 90 || c == 90) && a+b+c == 180)
            return 1;
        else if ((a >= 90 || b >= 90 || c >= 90) && a+b+c == 180)
            return 2;
        else if ( (a <= 90) && (b <= 90) && (c <= 90) && a+b+c == 180)
            return 3;
        else
            return 4;
    }
    
    public static int k(double set[])//Value for the TRIangle Array
    {
    //ALL ANGLES REQUIRED
        if ((a == b && b == c)  && a+b+c == 180)
            return 2;
        else if ((a == b || b == c || c == a) && a+b+c == 180)
            return 3;
        else if ((a != b && b != c) && a+b+c == 180)
            return 1;
        else
            return 4;
    }    
    public double[] sort(double[] set, int missing){
    	 A = set[0];
    	 a = set[1];
    	 B = set[2];
    	 b = set[3];
    	 C = set[4];
    	 c = set[5];

    	 
    	 
//    	if  ( B != 0 && A != 0 && c != 0  && C == 0){
//    		set[4] = C(set);
//    	 }else if ( B != 0 && C != 0 && A != 0 && c == 0){
//    		set[5] = c(set); 
//    	 }else if ( C != 0 && A != 0 && B != 0 && B == 0){
//    		 set[2] = B(set);
//    	 }else if ( B != 0 && C != 0 && A != 0 && b == 0){
//    		 set[3] = b(set);
//    	 }else if ( C != 0 && B != 0 && a != 0 && A == 0){
//    		 set[0] = A(set);
//    	 }else if ( B != 0 && C != 0 && A != 0 && a == 0){
//    		 set[1] = a(set);
//    	 }

   	 	return set;
   	 }

    
    //for missing side and a/b is known
    public double C(double[] set)//Finding Side C from c
    {
    	return Math.sqrt((A*A)+(B*B)-(2*A*B)*(Math.cos(Math.toRadians(c))));
    }
    
    public double c(double[] set)//Finding Angle c from all sides
    {
    	return Math.acos(((C*C)-(A*A)-(B*B))/(-2*A*B));
    }
    
    public double B(double[] set)//Finding Side B
    {
    	System.out.println("A: "+A+" C: "+C+" b:"+b);
    	return Math.sqrt((A*A)+(C*C)-(2*A*C)*(Math.cos(Math.toRadians(b))));
    }
    
    public double b(double[] set)//Finding Angle b
    {
    	return Math.acos(((B*B)-(A*A)-(C*C))/(-2*A*C));
    }
    
    public double A(double[] set)//Finding Side A
    {
    	return Math.sqrt((B*B)+(C*C)-(2*B*C)*(Math.cos(Math.toRadians(a))));
    }
    
    public double a(double[] set)//Finding Angle a
    {
    	return Math.acos(((A*A)-(B*B)-(C*C))/(-2*B*C));
    }
}
